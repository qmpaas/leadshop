module.exports = {
  siteroot: 'http://leadshop.com/index.php'
};
