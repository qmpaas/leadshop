module.exports = {
  siteroot: 'https://weapp.leadshop.vip/index.php'
};
