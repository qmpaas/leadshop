module.exports = {
  siteroot: 'https://test.leadshop.vip/index.php'
  // siteroot: 'https://dev.91bd.cn/index.php'
  // siteroot: 'http://localhost:8080/index.php'
};
