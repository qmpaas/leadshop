/*
 * @Description:
 * @Author: fjt
 * @Date: 2021-05-24 13:22:32
 * @LastEditTime: 2021-06-18 09:59:34
 * @LastEditors: fjt
 */
module.exports = {
  "siteroot": "https://dev.91bd.cn/index.php"
  // "siteroot": "https://test.leadshop.vip/index.php"
  // "siteroot": "https://class.leadshop.vip/index.php"
}
