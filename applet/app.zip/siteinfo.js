module.exports = {
  siteroot: 'http://localhost:8080/index.php'
};
