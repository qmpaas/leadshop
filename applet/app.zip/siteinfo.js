module.exports = {
  siteroot: 'https://test.leadshop.vip/index.php'
  // siteroot: 'http://localhost:8080/index.php'
};
