/*
 * @Description: 
 * @Author: fjt
 * @Date: 2021-05-24 13:22:32
 * @LastEditTime: 2021-05-28 10:07:06
 * @LastEditors: fjt
 */
module.exports = {
    "uniacid": "4",
    "acid": "3",
    "multiid": "0",
    "version": "1.2.0",
    "AppURL": "http://www.qmpaas.com/index.php",
    // "siteroot": "http://www.qmpaas.com/index.php",
    // "siteroot": "https://dev.91bd.cn/index.php",
    "siteroot": "https://test.leadshop.vip/index.php",
    "design_method": "3"
}