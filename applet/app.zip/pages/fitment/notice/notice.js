(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/fitment/notice/notice"],{"05a7":function(t,e,n){"use strict";n.r(e);var c=n("6ea6"),a=n("d8ae");for(var r in a)["default"].indexOf(r)<0&&function(t){n.d(e,t,(function(){return a[t]}))}(r);n("66bb");var u,i=n("f0c5"),o=Object(i["a"])(a["default"],c["b"],c["c"],!1,null,"30c3e1a6",null,!1,c["a"],u);e["default"]=o.exports},"3c70":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var c=function(){n.e("pages/fitment/notice/item").then(function(){return resolve(n("5f35"))}.bind(null,n)).catch(n.oe)},a={components:{item:c},props:{facade:{type:[Object,Array]},content:{type:[Object,Array]}},name:"notice"};e.default=a},"66bb":function(t,e,n){"use strict";var c=n("ddb7"),a=n.n(c);a.a},"6ea6":function(t,e,n){"use strict";var c;n.d(e,"b",(function(){return a})),n.d(e,"c",(function(){return r})),n.d(e,"a",(function(){return c}));var a=function(){var t=this,e=t.$createElement;t._self._c},r=[]},d8ae:function(t,e,n){"use strict";n.r(e);var c=n("3c70"),a=n.n(c);for(var r in c)["default"].indexOf(r)<0&&function(t){n.d(e,t,(function(){return c[t]}))}(r);e["default"]=a.a},ddb7:function(t,e,n){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/fitment/notice/notice-create-component',
    {
        'pages/fitment/notice/notice-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("05a7"))
        })
    },
    [['pages/fitment/notice/notice-create-component']]
]);
