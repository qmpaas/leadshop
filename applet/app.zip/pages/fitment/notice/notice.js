(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/fitment/notice/notice"],{"05a7":function(t,n,e){"use strict";e.r(n);var c=e("a238"),a=e("d8ae");for(var r in a)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return a[t]}))}(r);e("667b");var u,i=e("f0c5"),o=Object(i["a"])(a["default"],c["b"],c["c"],!1,null,"05cfd459",null,!1,c["a"],u);n["default"]=o.exports},"3c70":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var c=function(){e.e("pages/fitment/notice/item").then(function(){return resolve(e("5f35"))}.bind(null,e)).catch(e.oe)},a={components:{item:c},props:{facade:{type:[Object,Array]},content:{type:[Object,Array]}},name:"notice"};n.default=a},"667b":function(t,n,e){"use strict";var c=e("e202"),a=e.n(c);a.a},a238:function(t,n,e){"use strict";var c;e.d(n,"b",(function(){return a})),e.d(n,"c",(function(){return r})),e.d(n,"a",(function(){return c}));var a=function(){var t=this,n=t.$createElement;t._self._c},r=[]},d8ae:function(t,n,e){"use strict";e.r(n);var c=e("3c70"),a=e.n(c);for(var r in c)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return c[t]}))}(r);n["default"]=a.a},e202:function(t,n,e){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/fitment/notice/notice-create-component',
    {
        'pages/fitment/notice/notice-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("05a7"))
        })
    },
    [['pages/fitment/notice/notice-create-component']]
]);
