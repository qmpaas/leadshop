(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/fitment/notice/notice"],{"05a7":function(t,n,e){"use strict";e.r(n);var a=e("4e6f"),c=e("d8aea");for(var r in c)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return c[t]}))}(r);e("f771");var u,f=e("5d80"),i=Object(f["a"])(c["default"],a["b"],a["c"],!1,null,"452ca6d2",null,!1,a["a"],u);n["default"]=i.exports},"38af":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a=function(){e.e("pages/fitment/notice/item").then(function(){return resolve(e("5f35"))}.bind(null,e)).catch(e.oe)},c={components:{item:a},props:{facade:{type:[Object,Array]},content:{type:[Object,Array]}},name:"notice"};n.default=c},"4e6f":function(t,n,e){"use strict";var a;e.d(n,"b",(function(){return c})),e.d(n,"c",(function(){return r})),e.d(n,"a",(function(){return a}));var c=function(){var t=this,n=t.$createElement;t._self._c},r=[]},c10d:function(t,n,e){},d8aea:function(t,n,e){"use strict";e.r(n);var a=e("38af"),c=e.n(a);for(var r in a)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return a[t]}))}(r);n["default"]=c.a},f771:function(t,n,e){"use strict";var a=e("c10d"),c=e.n(a);c.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/fitment/notice/notice-create-component',
    {
        'pages/fitment/notice/notice-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f0d1')['createComponent'](__webpack_require__("05a7"))
        })
    },
    [['pages/fitment/notice/notice-create-component']]
]);
