(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/fitment/separate/separate"],{"64f7":function(e,t,n){"use strict";n.r(t);var r=n("ec7a"),a=n.n(r);for(var c in r)["default"].indexOf(c)<0&&function(e){n.d(t,e,(function(){return r[e]}))}(c);t["default"]=a.a},9990:function(e,t,n){"use strict";n.r(t);var r=n("ec75"),a=n("64f7");for(var c in a)["default"].indexOf(c)<0&&function(e){n.d(t,e,(function(){return a[e]}))}(c);var u,f=n("f0c5"),i=Object(f["a"])(a["default"],r["b"],r["c"],!1,null,null,null,!1,r["a"],u);t["default"]=i.exports},ec75:function(e,t,n){"use strict";var r;n.d(t,"b",(function(){return a})),n.d(t,"c",(function(){return c})),n.d(t,"a",(function(){return r}));var a=function(){var e=this,t=e.$createElement;e._self._c},c=[]},ec7a:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r={props:{facade:{type:[Object,Array]},content:{type:[Object,Array]}},computed:{margin:function(){return 1==this.facade.chamfer_style?0:10}}};t.default=r}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/fitment/separate/separate-create-component',
    {
        'pages/fitment/separate/separate-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("9990"))
        })
    },
    [['pages/fitment/separate/separate-create-component']]
]);
