(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/fitment/separate/separate"],{"64f7":function(t,e,n){"use strict";n.r(e);var r=n("c3c8"),a=n.n(r);for(var u in r)["default"].indexOf(u)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(u);e["default"]=a.a},"6b60":function(t,e,n){"use strict";var r;n.d(e,"b",(function(){return a})),n.d(e,"c",(function(){return u})),n.d(e,"a",(function(){return r}));var a=function(){var t=this,e=t.$createElement;t._self._c},u=[]},9990:function(t,e,n){"use strict";n.r(e);var r=n("6b60"),a=n("64f7");for(var u in a)["default"].indexOf(u)<0&&function(t){n.d(e,t,(function(){return a[t]}))}(u);var c,f=n("8add"),i=Object(f["a"])(a["default"],r["b"],r["c"],!1,null,null,null,!1,r["a"],c);e["default"]=i.exports},c3c8:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={props:{facade:{type:[Object,Array]},content:{type:[Object,Array]}},computed:{margin:function(){return 1==this.facade.chamfer_style?0:10}}};e.default=r}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/fitment/separate/separate-create-component',
    {
        'pages/fitment/separate/separate-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('a9ee')['createComponent'](__webpack_require__("9990"))
        })
    },
    [['pages/fitment/separate/separate-create-component']]
]);
