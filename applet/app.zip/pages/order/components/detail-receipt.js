(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/detail-receipt"],{"0472":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r={name:"detail-receipt",props:{consigneeInfo:{type:Object,default:function(){return{name:"",mobile:"",province:"",city:"",district:"",address:""}}}}};t.default=r},1643:function(n,t,e){"use strict";var r=e("f93bc"),a=e.n(r);a.a},6831:function(n,t,e){"use strict";e.r(t);var r=e("0472"),a=e.n(r);for(var u in r)["default"].indexOf(u)<0&&function(n){e.d(t,n,(function(){return r[n]}))}(u);t["default"]=a.a},"90aa":function(n,t,e){"use strict";var r;e.d(t,"b",(function(){return a})),e.d(t,"c",(function(){return u})),e.d(t,"a",(function(){return r}));var a=function(){var n=this,t=n.$createElement;n._self._c},u=[]},9160:function(n,t,e){"use strict";e.r(t);var r=e("90aa"),a=e("6831");for(var u in a)["default"].indexOf(u)<0&&function(n){e.d(t,n,(function(){return a[n]}))}(u);e("1643");var c,i=e("98a2"),o=Object(i["a"])(a["default"],r["b"],r["c"],!1,null,"98136094",null,!1,r["a"],c);t["default"]=o.exports},f93bc:function(n,t,e){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/detail-receipt-create-component',
    {
        'pages/order/components/detail-receipt-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('3be4')['createComponent'](__webpack_require__("9160"))
        })
    },
    [['pages/order/components/detail-receipt-create-component']]
]);
