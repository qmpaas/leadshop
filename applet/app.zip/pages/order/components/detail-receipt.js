(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/detail-receipt"],{"549e":function(e,n,t){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"detail-receipt",props:{consigneeInfo:{type:Object,default:function(){return{name:"",mobile:"",province:"",city:"",district:"",address:""}}}}};n.default=r},6831:function(e,n,t){"use strict";t.r(n);var r=t("549e"),c=t.n(r);for(var u in r)["default"].indexOf(u)<0&&function(e){t.d(n,e,(function(){return r[e]}))}(u);n["default"]=c.a},"8e9a":function(e,n,t){"use strict";var r;t.d(n,"b",(function(){return c})),t.d(n,"c",(function(){return u})),t.d(n,"a",(function(){return r}));var c=function(){var e=this,n=e.$createElement;e._self._c},u=[]},9160:function(e,n,t){"use strict";t.r(n);var r=t("8e9a"),c=t("6831");for(var u in c)["default"].indexOf(u)<0&&function(e){t.d(n,e,(function(){return c[e]}))}(u);t("f9be");var a,i=t("f0c5"),f=Object(i["a"])(c["default"],r["b"],r["c"],!1,null,"bcdd66ac",null,!1,r["a"],a);n["default"]=f.exports},f500:function(e,n,t){},f9be:function(e,n,t){"use strict";var r=t("f500"),c=t.n(r);c.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/detail-receipt-create-component',
    {
        'pages/order/components/detail-receipt-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("9160"))
        })
    },
    [['pages/order/components/detail-receipt-create-component']]
]);
