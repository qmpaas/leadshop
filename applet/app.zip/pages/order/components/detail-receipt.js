(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/detail-receipt"],{1643:function(e,n,t){"use strict";var r=t("61e1"),a=t.n(r);a.a},"61e1":function(e,n,t){},6383:function(e,n,t){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"detail-receipt",props:{consigneeInfo:{type:Object,default:function(){return{name:"",mobile:"",province:"",city:"",district:"",address:""}}}}};n.default=r},6831:function(e,n,t){"use strict";t.r(n);var r=t("6383"),a=t.n(r);for(var u in r)["default"].indexOf(u)<0&&function(e){t.d(n,e,(function(){return r[e]}))}(u);n["default"]=a.a},"90aa":function(e,n,t){"use strict";var r;t.d(n,"b",(function(){return a})),t.d(n,"c",(function(){return u})),t.d(n,"a",(function(){return r}));var a=function(){var e=this,n=e.$createElement;e._self._c},u=[]},9160:function(e,n,t){"use strict";t.r(n);var r=t("90aa"),a=t("6831");for(var u in a)["default"].indexOf(u)<0&&function(e){t.d(n,e,(function(){return a[e]}))}(u);t("1643");var i,c=t("7702"),o=Object(c["a"])(a["default"],r["b"],r["c"],!1,null,"98136094",null,!1,r["a"],i);n["default"]=o.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/detail-receipt-create-component',
    {
        'pages/order/components/detail-receipt-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('255a')['createComponent'](__webpack_require__("9160"))
        })
    },
    [['pages/order/components/detail-receipt-create-component']]
]);
