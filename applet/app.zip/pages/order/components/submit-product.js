(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/submit-product"],{6464:function(t,n,a){"use strict";var e=a("a76a"),r=a.n(e);r.a},a2cb:function(t,n,a){"use strict";a.r(n);var e=a("b6df"),r=a("d336");for(var u in r)["default"].indexOf(u)<0&&function(t){a.d(n,t,(function(){return r[t]}))}(u);a("6464");var i,o=a("f0c5"),f=Object(o["a"])(r["default"],e["b"],e["c"],!1,null,"6d94675a",null,!1,e["a"],i);n["default"]=f.exports},a76a:function(t,n,a){},b6df:function(t,n,a){"use strict";var e;a.d(n,"b",(function(){return r})),a.d(n,"c",(function(){return u})),a.d(n,"a",(function(){return e}));var r=function(){var t=this,n=t.$createElement,a=(t._self._c,t.__map(t.goodsData,(function(n,a){var e=t.__get_orig(n),r=t._f("getFail")(n.failure_reason,n.failure_number);return{$orig:e,f0:r}})));t.$mp.data=Object.assign({},{$root:{l0:a}})},u=[]},d336:function(t,n,a){"use strict";a.r(n);var e=a("d45d"),r=a.n(e);for(var u in e)["default"].indexOf(u)<0&&function(t){a.d(n,t,(function(){return e[t]}))}(u);n["default"]=r.a},d45d:function(t,n,a){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var e={name:"submit-product",props:{goodsData:{type:Array,default:[]}},filters:{getFail:function(t,n){switch(t){case"limit":return"商品限购"+n+"件"}}}};n.default=e}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/submit-product-create-component',
    {
        'pages/order/components/submit-product-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("a2cb"))
        })
    },
    [['pages/order/components/submit-product-create-component']]
]);
