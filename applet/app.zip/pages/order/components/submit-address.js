(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/submit-address"],{"0132":function(n,t,e){"use strict";var u=e("83cf"),a=e.n(u);a.a},"78b5":function(n,t,e){"use strict";e.r(t);var u=e("fab5"),a=e.n(u);for(var i in u)["default"].indexOf(i)<0&&function(n){e.d(t,n,(function(){return u[n]}))}(i);t["default"]=a.a},"83cf":function(n,t,e){},c923:function(n,t,e){"use strict";var u;e.d(t,"b",(function(){return a})),e.d(t,"c",(function(){return i})),e.d(t,"a",(function(){return u}));var a=function(){var n=this,t=n.$createElement;n._self._c},i=[]},d78f:function(n,t,e){"use strict";e.r(t);var u=e("c923"),a=e("78b5");for(var i in a)["default"].indexOf(i)<0&&function(n){e.d(t,n,(function(){return a[n]}))}(i);e("0132");var r,c=e("f0c5"),f=Object(c["a"])(a["default"],u["b"],u["c"],!1,null,"693388f5",null,!1,u["a"],r);t["default"]=f.exports},fab5:function(n,t,e){"use strict";(function(n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var e={name:"submit-address",props:{consigneeInfo:{type:Object}},methods:{navigateTo:function(){var t="/pages/user/shipping-address?submit=1";this.consigneeInfo&&(t+="&id="+this.consigneeInfo.id),n.navigateTo({url:t})}}};t.default=e}).call(this,e("543d")["default"])}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/submit-address-create-component',
    {
        'pages/order/components/submit-address-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("d78f"))
        })
    },
    [['pages/order/components/submit-address-create-component']]
]);
