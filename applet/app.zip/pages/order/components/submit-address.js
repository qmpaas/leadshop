(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/submit-address"],{1314:function(n,e,t){"use strict";(function(n){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var t={name:"submit-address",props:{consigneeInfo:{type:Object}},methods:{navigateTo:function(){var e="/pages/user/shipping-address?submit=1";this.consigneeInfo&&(e+="&id="+this.consigneeInfo.id),n.navigateTo({url:e})}}};e.default=t}).call(this,t("a9ee")["default"])},"5c00":function(n,e,t){"use strict";var a;t.d(e,"b",(function(){return u})),t.d(e,"c",(function(){return i})),t.d(e,"a",(function(){return a}));var u=function(){var n=this,e=n.$createElement;n._self._c},i=[]},"78b5":function(n,e,t){"use strict";t.r(e);var a=t("1314"),u=t.n(a);for(var i in a)["default"].indexOf(i)<0&&function(n){t.d(e,n,(function(){return a[n]}))}(i);e["default"]=u.a},ced2:function(n,e,t){},d78f:function(n,e,t){"use strict";t.r(e);var a=t("5c00"),u=t("78b5");for(var i in u)["default"].indexOf(i)<0&&function(n){t.d(e,n,(function(){return u[n]}))}(i);t("da5b");var r,c=t("8add"),o=Object(c["a"])(u["default"],a["b"],a["c"],!1,null,"6a17f641",null,!1,a["a"],r);e["default"]=o.exports},da5b:function(n,e,t){"use strict";var a=t("ced2"),u=t.n(a);u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/submit-address-create-component',
    {
        'pages/order/components/submit-address-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('a9ee')['createComponent'](__webpack_require__("d78f"))
        })
    },
    [['pages/order/components/submit-address-create-component']]
]);
