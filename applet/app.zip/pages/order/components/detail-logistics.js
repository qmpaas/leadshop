(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/detail-logistics"],{"05a71":function(t,e,n){},"07e8":function(t,e,n){"use strict";n.r(e);var i=n("888a"),a=n("b6cf");for(var r in a)["default"].indexOf(r)<0&&function(t){n.d(e,t,(function(){return a[t]}))}(r);n("d278");var o,u=n("f0c5"),c=Object(u["a"])(a["default"],i["b"],i["c"],!1,null,"3c5c3978",null,!1,i["a"],o);e["default"]=c.exports},"888a":function(t,e,n){"use strict";var i;n.d(e,"b",(function(){return a})),n.d(e,"c",(function(){return r})),n.d(e,"a",(function(){return i}));var a=function(){var t=this,e=t.$createElement,n=(t._self._c,1===t.freight.type?t.$h.test.isEmpty(t.freightObj.status):null);t.$mp.data=Object.assign({},{$root:{g0:n}})},r=[]},b6cf:function(t,e,n){"use strict";n.r(e);var i=n("d808"),a=n.n(i);for(var r in i)["default"].indexOf(r)<0&&function(t){n.d(e,t,(function(){return i[t]}))}(r);e["default"]=a.a},d278:function(t,e,n){"use strict";var i=n("05a71"),a=n.n(i);a.a},d808:function(t,e,n){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var n={name:"detail-logistics",props:{freight:{type:Object,default:function(){return{}}},freightObj:{type:Object,default:function(){return{status:0}}},mobile:{type:String}},methods:{navigateTo:function(){t.navigateTo({url:"/pages/order/logistics?no="+this.freight.freight_sn+"&name="+this.freight.logistics_company+"&mobile="+this.mobile})},copy:function(t){this.uniCopy({content:t})}}};e.default=n}).call(this,n("543d")["default"])}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/detail-logistics-create-component',
    {
        'pages/order/components/detail-logistics-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("07e8"))
        })
    },
    [['pages/order/components/detail-logistics-create-component']]
]);
