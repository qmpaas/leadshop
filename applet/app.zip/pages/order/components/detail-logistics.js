(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/detail-logistics"],{"07e8":function(t,e,n){"use strict";n.r(e);var i=n("99e4"),r=n("b6cf");for(var a in r)["default"].indexOf(a)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(a);n("632e");var o,u=n("f0c5"),c=Object(u["a"])(r["default"],i["b"],i["c"],!1,null,"8e5fba52",null,!1,i["a"],o);e["default"]=c.exports},"632e":function(t,e,n){"use strict";var i=n("d0a0"),r=n.n(i);r.a},"99e4":function(t,e,n){"use strict";var i;n.d(e,"b",(function(){return r})),n.d(e,"c",(function(){return a})),n.d(e,"a",(function(){return i}));var r=function(){var t=this,e=t.$createElement,n=(t._self._c,1===t.freight.type?t.$h.test.isEmpty(t.freightObj.status):null);t.$mp.data=Object.assign({},{$root:{g0:n}})},a=[]},b6cf:function(t,e,n){"use strict";n.r(e);var i=n("d808"),r=n.n(i);for(var a in i)["default"].indexOf(a)<0&&function(t){n.d(e,t,(function(){return i[t]}))}(a);e["default"]=r.a},d0a0:function(t,e,n){},d808:function(t,e,n){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var n={name:"detail-logistics",props:{freight:{type:Object,default:function(){return{}}},freightObj:{type:Object,default:function(){return{status:0}}},mobile:{type:String}},methods:{navigateTo:function(){t.navigateTo({url:"/pages/order/logistics?no="+this.freight.freight_sn+"&name="+this.freight.logistics_company+"&mobile="+this.mobile})},copy:function(t){this.uniCopy({content:t})}}};e.default=n}).call(this,n("543d")["default"])}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/detail-logistics-create-component',
    {
        'pages/order/components/detail-logistics-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("07e8"))
        })
    },
    [['pages/order/components/detail-logistics-create-component']]
]);
