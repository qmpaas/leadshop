(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/detail-logistics"],{"07e8":function(t,e,n){"use strict";n.r(e);var r=n("314d"),a=n("b6cf");for(var u in a)["default"].indexOf(u)<0&&function(t){n.d(e,t,(function(){return a[t]}))}(u);n("5458");var i,o=n("f0c5"),c=Object(o["a"])(a["default"],r["b"],r["c"],!1,null,"a378010e",null,!1,r["a"],i);e["default"]=c.exports},"314d":function(t,e,n){"use strict";var r;n.d(e,"b",(function(){return a})),n.d(e,"c",(function(){return u})),n.d(e,"a",(function(){return r}));var a=function(){var t=this,e=t.$createElement;t._self._c},u=[]},5458:function(t,e,n){"use strict";var r=n("df81"),a=n.n(r);a.a},b6cf:function(t,e,n){"use strict";n.r(e);var r=n("d808"),a=n.n(r);for(var u in r)["default"].indexOf(u)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(u);e["default"]=a.a},d808:function(t,e,n){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var n={name:"detail-logistics",props:{freight:{type:Array,default:[]},orderId:{type:Number}},methods:{navigateTo:function(){t.navigateTo({url:"/pages/order/package?id="+this.orderId})}}};e.default=n}).call(this,n("543d")["default"])},df81:function(t,e,n){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/detail-logistics-create-component',
    {
        'pages/order/components/detail-logistics-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("07e8"))
        })
    },
    [['pages/order/components/detail-logistics-create-component']]
]);
