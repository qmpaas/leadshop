(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/detail-price"],{"57f8":function(t,e,n){},7963:function(t,e,n){"use strict";n.r(e);var u=n("ae2b"),r=n("f6b5");for(var a in r)["default"].indexOf(a)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(a);n("d5a4");var o,c=n("f0c5"),f=Object(c["a"])(r["default"],u["b"],u["c"],!1,null,"7bd9edda",null,!1,u["a"],o);e["default"]=f.exports},"8c77":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"detail-price",props:{goodsAmount:{type:String,default:function(){return""}},freightAmount:{type:String,default:function(){return""}},payAmount:{type:String,default:function(){return""}},status:{type:Number,default:function(){return 0}},couponReduced:{type:String,default:function(){return""}},storeReduced:{type:Number,default:function(){return 0}}}};e.default=u},ae2b:function(t,e,n){"use strict";var u;n.d(e,"b",(function(){return r})),n.d(e,"c",(function(){return a})),n.d(e,"a",(function(){return u}));var r=function(){var t=this,e=t.$createElement,n=(t._self._c,Number(t.couponReduced)),u=t.storeReduced?t._f("floatPrice")(t.storeReduced):null;t.$mp.data=Object.assign({},{$root:{m0:n,f0:u}})},a=[]},d5a4:function(t,e,n){"use strict";var u=n("57f8"),r=n.n(u);r.a},f6b5:function(t,e,n){"use strict";n.r(e);var u=n("8c77"),r=n.n(u);for(var a in u)["default"].indexOf(a)<0&&function(t){n.d(e,t,(function(){return u[t]}))}(a);e["default"]=r.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/detail-price-create-component',
    {
        'pages/order/components/detail-price-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("7963"))
        })
    },
    [['pages/order/components/detail-price-create-component']]
]);
