(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/detail-price"],{"56fc":function(t,e,n){},6629:function(t,e,n){"use strict";var u=n("56fc"),r=n.n(u);r.a},7963:function(t,e,n){"use strict";n.r(e);var u=n("c68f"),r=n("f6b5");for(var c in r)["default"].indexOf(c)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(c);n("6629");var f,o=n("f0c5"),a=Object(o["a"])(r["default"],u["b"],u["c"],!1,null,"521ff914",null,!1,u["a"],f);e["default"]=a.exports},"8c77":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"detail-price",props:{detail:Object,goodsAmount:{type:String,default:function(){return""}},freightAmount:{type:String,default:function(){return""}},payAmount:{type:String,default:function(){return""}},status:{type:Number,default:function(){return 0}},couponReduced:{type:String,default:function(){return""}},storeReduced:{type:Number,default:function(){return 0}}},mounted:function(){}};e.default=u},c68f:function(t,e,n){"use strict";var u;n.d(e,"b",(function(){return r})),n.d(e,"c",(function(){return c})),n.d(e,"a",(function(){return u}));var r=function(){var t=this,e=t.$createElement,n=(t._self._c,Number(t.couponReduced)),u=t.storeReduced?t._f("floatPrice")(t.storeReduced):null;t.$mp.data=Object.assign({},{$root:{m0:n,f0:u}})},c=[]},f6b5:function(t,e,n){"use strict";n.r(e);var u=n("8c77"),r=n.n(u);for(var c in u)["default"].indexOf(c)<0&&function(t){n.d(e,t,(function(){return u[t]}))}(c);e["default"]=r.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/detail-price-create-component',
    {
        'pages/order/components/detail-price-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("7963"))
        })
    },
    [['pages/order/components/detail-price-create-component']]
]);
