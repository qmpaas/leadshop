(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/submit-comments"],{"1d08":function(e,t,n){},"1f30":function(e,t,n){"use strict";n.r(t);var u=n("fffc"),a=n("be54");for(var f in a)["default"].indexOf(f)<0&&function(e){n.d(t,e,(function(){return a[e]}))}(f);n("e5a4");var r,o=n("f0c5"),c=Object(o["a"])(a["default"],u["b"],u["c"],!1,null,"7912ebe9",null,!1,u["a"],r);t["default"]=c.exports},be54:function(e,t,n){"use strict";n.r(t);var u=n("efb8"),a=n.n(u);for(var f in u)["default"].indexOf(f)<0&&function(e){n.d(t,e,(function(){return u[e]}))}(f);t["default"]=a.a},e5a4:function(e,t,n){"use strict";var u=n("1d08"),a=n.n(u);a.a},efb8:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var n={name:"submit-comments",props:{note:String},methods:{navigateTo:function(){e.navigateTo({url:"/pages/other/buyer-message?note="+this.note})}}};t.default=n}).call(this,n("543d")["default"])},fffc:function(e,t,n){"use strict";var u;n.d(t,"b",(function(){return a})),n.d(t,"c",(function(){return f})),n.d(t,"a",(function(){return u}));var a=function(){var e=this,t=e.$createElement;e._self._c},f=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/submit-comments-create-component',
    {
        'pages/order/components/submit-comments-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("1f30"))
        })
    },
    [['pages/order/components/submit-comments-create-component']]
]);
