(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/submit-comments"],{"1f30":function(e,t,n){"use strict";n.r(t);var u=n("f44e"),a=n("be54");for(var r in a)["default"].indexOf(r)<0&&function(e){n.d(t,e,(function(){return a[e]}))}(r);n("69fd");var o,c=n("8add"),f=Object(c["a"])(a["default"],u["b"],u["c"],!1,null,"72eef054",null,!1,u["a"],o);t["default"]=f.exports},"69fd":function(e,t,n){"use strict";var u=n("d9dc"),a=n.n(u);a.a},"8c13":function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var n={name:"submit-comments",props:{note:String},methods:{navigateTo:function(){e.navigateTo({url:"/pages/other/buyer-message?note="+this.note})}}};t.default=n}).call(this,n("a9ee")["default"])},be54:function(e,t,n){"use strict";n.r(t);var u=n("8c13"),a=n.n(u);for(var r in u)["default"].indexOf(r)<0&&function(e){n.d(t,e,(function(){return u[e]}))}(r);t["default"]=a.a},d9dc:function(e,t,n){},f44e:function(e,t,n){"use strict";var u;n.d(t,"b",(function(){return a})),n.d(t,"c",(function(){return r})),n.d(t,"a",(function(){return u}));var a=function(){var e=this,t=e.$createElement;e._self._c},r=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/submit-comments-create-component',
    {
        'pages/order/components/submit-comments-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('a9ee')['createComponent'](__webpack_require__("1f30"))
        })
    },
    [['pages/order/components/submit-comments-create-component']]
]);
