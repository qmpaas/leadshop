(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/submit-comments"],{"1d68":function(t,e,n){},"1f30":function(t,e,n){"use strict";n.r(e);var u=n("f44e"),r=n("be54");for(var a in r)["default"].indexOf(a)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(a);n("69fd");var o,f=n("98a2"),c=Object(f["a"])(r["default"],u["b"],u["c"],!1,null,"72eef054",null,!1,u["a"],o);e["default"]=c.exports},"69fd":function(t,e,n){"use strict";var u=n("1d68"),r=n.n(u);r.a},"6fc7":function(t,e,n){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var n={name:"submit-comments",props:{note:String},methods:{navigateTo:function(){t.navigateTo({url:"/pages/other/buyer-message?note="+this.note})}}};e.default=n}).call(this,n("3be4")["default"])},be54:function(t,e,n){"use strict";n.r(e);var u=n("6fc7"),r=n.n(u);for(var a in u)["default"].indexOf(a)<0&&function(t){n.d(e,t,(function(){return u[t]}))}(a);e["default"]=r.a},f44e:function(t,e,n){"use strict";var u;n.d(e,"b",(function(){return r})),n.d(e,"c",(function(){return a})),n.d(e,"a",(function(){return u}));var r=function(){var t=this,e=t.$createElement;t._self._c},a=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/submit-comments-create-component',
    {
        'pages/order/components/submit-comments-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('3be4')['createComponent'](__webpack_require__("1f30"))
        })
    },
    [['pages/order/components/submit-comments-create-component']]
]);
