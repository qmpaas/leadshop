(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/submit-comments"],{"0c12":function(t,n,e){},"1f30":function(t,n,e){"use strict";e.r(n);var u=e("f44e"),r=e("be54");for(var f in r)["default"].indexOf(f)<0&&function(t){e.d(n,t,(function(){return r[t]}))}(f);e("69fd");var o,a=e("5d80"),c=Object(a["a"])(r["default"],u["b"],u["c"],!1,null,"72eef054",null,!1,u["a"],o);n["default"]=c.exports},"69fd":function(t,n,e){"use strict";var u=e("0c12"),r=e.n(u);r.a},be54:function(t,n,e){"use strict";e.r(n);var u=e("f327"),r=e.n(u);for(var f in u)["default"].indexOf(f)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(f);n["default"]=r.a},f327:function(t,n,e){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var e={name:"submit-comments",props:{note:String},methods:{navigateTo:function(){t.navigateTo({url:"/pages/other/buyer-message?note="+this.note})}}};n.default=e}).call(this,e("f0d1")["default"])},f44e:function(t,n,e){"use strict";var u;e.d(n,"b",(function(){return r})),e.d(n,"c",(function(){return f})),e.d(n,"a",(function(){return u}));var r=function(){var t=this,n=t.$createElement;t._self._c},f=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/submit-comments-create-component',
    {
        'pages/order/components/submit-comments-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f0d1')['createComponent'](__webpack_require__("1f30"))
        })
    },
    [['pages/order/components/submit-comments-create-component']]
]);
