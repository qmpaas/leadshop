(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/submit-comments"],{"1f30":function(t,n,e){"use strict";e.r(n);var a=e("f44e"),u=e("be54");for(var r in u)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(r);e("69fd");var o,f=e("7702"),i=Object(f["a"])(u["default"],a["b"],a["c"],!1,null,"72eef054",null,!1,a["a"],o);n["default"]=i.exports},4146:function(t,n,e){},"69fd":function(t,n,e){"use strict";var a=e("4146"),u=e.n(a);u.a},"98aa":function(t,n,e){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var e={name:"submit-comments",props:{note:String},methods:{navigateTo:function(){t.navigateTo({url:"/pages/other/buyer-message?note="+this.note})}}};n.default=e}).call(this,e("255a")["default"])},be54:function(t,n,e){"use strict";e.r(n);var a=e("98aa"),u=e.n(a);for(var r in a)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return a[t]}))}(r);n["default"]=u.a},f44e:function(t,n,e){"use strict";var a;e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return r})),e.d(n,"a",(function(){return a}));var u=function(){var t=this,n=t.$createElement;t._self._c},r=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/submit-comments-create-component',
    {
        'pages/order/components/submit-comments-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('255a')['createComponent'](__webpack_require__("1f30"))
        })
    },
    [['pages/order/components/submit-comments-create-component']]
]);
