(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-args"],{1479:function(n,t,e){},3098:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var a=function(){e.e("components/he-popup").then(function(){return resolve(e("c2c4"))}.bind(null,e)).catch(e.oe)},u={name:"detail-args",components:{HePopup:a},props:{value:{type:Boolean},list:{type:Array}},computed:{showModal:{get:function(n){var t=n.value;return t},set:function(n){this.$emit("input",n)}}}};t.default=u},"54a1":function(n,t,e){"use strict";var a;e.d(t,"b",(function(){return u})),e.d(t,"c",(function(){return o})),e.d(t,"a",(function(){return a}));var u=function(){var n=this,t=n.$createElement;n._self._c;n._isMounted||(n.e0=function(t){n.showModal=!1})},o=[]},"826a":function(n,t,e){"use strict";e.r(t);var a=e("54a1"),u=e("caae");for(var o in u)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return u[n]}))}(o);e("b6b5");var r,c=e("98a2"),i=Object(c["a"])(u["default"],a["b"],a["c"],!1,null,"1ba84c24",null,!1,a["a"],r);t["default"]=i.exports},b6b5:function(n,t,e){"use strict";var a=e("1479"),u=e.n(a);u.a},caae:function(n,t,e){"use strict";e.r(t);var a=e("3098"),u=e.n(a);for(var o in a)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return a[n]}))}(o);t["default"]=u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-args-create-component',
    {
        'pages/goods/components/detail-args-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('3be4')['createComponent'](__webpack_require__("826a"))
        })
    },
    [['pages/goods/components/detail-args-create-component']]
]);
