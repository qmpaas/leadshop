(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-args"],{"017c":function(n,t,e){},"4d6b":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u=function(){e.e("components/he-popup").then(function(){return resolve(e("c2c4"))}.bind(null,e)).catch(e.oe)},a={name:"detail-args",components:{HePopup:u},props:{value:{type:Boolean},list:{type:Array}},computed:{showModal:{get:function(n){var t=n.value;return t},set:function(n){this.$emit("input",n)}}}};t.default=a},"54a1":function(n,t,e){"use strict";var u;e.d(t,"b",(function(){return a})),e.d(t,"c",(function(){return o})),e.d(t,"a",(function(){return u}));var a=function(){var n=this,t=n.$createElement;n._self._c;n._isMounted||(n.e0=function(t){n.showModal=!1})},o=[]},"826a":function(n,t,e){"use strict";e.r(t);var u=e("54a1"),a=e("caae");for(var o in a)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return a[n]}))}(o);e("b6b5");var c,r=e("5d80"),i=Object(r["a"])(a["default"],u["b"],u["c"],!1,null,"1ba84c24",null,!1,u["a"],c);t["default"]=i.exports},b6b5:function(n,t,e){"use strict";var u=e("017c"),a=e.n(u);a.a},caae:function(n,t,e){"use strict";e.r(t);var u=e("4d6b"),a=e.n(u);for(var o in u)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return u[n]}))}(o);t["default"]=a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-args-create-component',
    {
        'pages/goods/components/detail-args-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f0d1')['createComponent'](__webpack_require__("826a"))
        })
    },
    [['pages/goods/components/detail-args-create-component']]
]);
