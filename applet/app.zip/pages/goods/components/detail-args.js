(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-args"],{"2ab1":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var a=function(){e.e("components/he-popup").then(function(){return resolve(e("c2c4"))}.bind(null,e)).catch(e.oe)},u={name:"detail-args",components:{HePopup:a},props:{value:{type:Boolean},list:{type:Array}},computed:{showModal:{get:function(n){var t=n.value;return t},set:function(n){this.$emit("input",n)}}}};t.default=u},"420d":function(n,t,e){},"603a":function(n,t,e){"use strict";var a=e("420d"),u=e.n(a);u.a},"826a":function(n,t,e){"use strict";e.r(t);var a=e("91fa"),u=e("caae");for(var o in u)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return u[n]}))}(o);e("603a");var c,r=e("f0c5"),i=Object(r["a"])(u["default"],a["b"],a["c"],!1,null,"2fdc1a42",null,!1,a["a"],c);t["default"]=i.exports},"91fa":function(n,t,e){"use strict";var a;e.d(t,"b",(function(){return u})),e.d(t,"c",(function(){return o})),e.d(t,"a",(function(){return a}));var u=function(){var n=this,t=n.$createElement;n._self._c;n._isMounted||(n.e0=function(t){n.showModal=!1})},o=[]},caae:function(n,t,e){"use strict";e.r(t);var a=e("2ab1"),u=e.n(a);for(var o in a)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return a[n]}))}(o);t["default"]=u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-args-create-component',
    {
        'pages/goods/components/detail-args-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("826a"))
        })
    },
    [['pages/goods/components/detail-args-create-component']]
]);
