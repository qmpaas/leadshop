(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-rich"],{"088c":function(n,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r=function(){Promise.all([t.e("common/vendor"),t.e("components/he-html/he-html")]).then(function(){return resolve(t("7dc4"))}.bind(null,t)).catch(t.oe)},c={name:"detail-rich",props:{content:{type:[String,Array]}},components:{heRich:r}};e.default=c},"18b3":function(n,e,t){"use strict";t.r(e);var r=t("691f"),c=t("9aa4");for(var a in c)["default"].indexOf(a)<0&&function(n){t.d(e,n,(function(){return c[n]}))}(a);t("7b72");var o,u=t("f0c5"),i=Object(u["a"])(c["default"],r["b"],r["c"],!1,null,"41335e0a",null,!1,r["a"],o);e["default"]=i.exports},"691f":function(n,e,t){"use strict";var r;t.d(e,"b",(function(){return c})),t.d(e,"c",(function(){return a})),t.d(e,"a",(function(){return r}));var c=function(){var n=this,e=n.$createElement;n._self._c},a=[]},"7b72":function(n,e,t){"use strict";var r=t("eb7a"),c=t.n(r);c.a},"9aa4":function(n,e,t){"use strict";t.r(e);var r=t("088c"),c=t.n(r);for(var a in r)["default"].indexOf(a)<0&&function(n){t.d(e,n,(function(){return r[n]}))}(a);e["default"]=c.a},eb7a:function(n,e,t){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-rich-create-component',
    {
        'pages/goods/components/detail-rich-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("18b3"))
        })
    },
    [['pages/goods/components/detail-rich-create-component']]
]);
