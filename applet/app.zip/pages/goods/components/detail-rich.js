(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-rich"],{"088c":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var c=function(){Promise.all([e.e("common/vendor"),e.e("components/he-html/he-html")]).then(function(){return resolve(e("7dc4"))}.bind(null,e)).catch(e.oe)},r={name:"detail-rich",props:{content:{type:[String,Array]}},components:{heRich:c}};t.default=r},"18b3":function(n,t,e){"use strict";e.r(t);var c=e("4dcc"),r=e("9aa4");for(var o in r)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return r[n]}))}(o);e("ea27");var a,u=e("f0c5"),i=Object(u["a"])(r["default"],c["b"],c["c"],!1,null,"dc1363cc",null,!1,c["a"],a);t["default"]=i.exports},"46bc":function(n,t,e){},"4dcc":function(n,t,e){"use strict";var c;e.d(t,"b",(function(){return r})),e.d(t,"c",(function(){return o})),e.d(t,"a",(function(){return c}));var r=function(){var n=this,t=n.$createElement;n._self._c},o=[]},"9aa4":function(n,t,e){"use strict";e.r(t);var c=e("088c"),r=e.n(c);for(var o in c)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return c[n]}))}(o);t["default"]=r.a},ea27:function(n,t,e){"use strict";var c=e("46bc"),r=e.n(c);r.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-rich-create-component',
    {
        'pages/goods/components/detail-rich-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("18b3"))
        })
    },
    [['pages/goods/components/detail-rich-create-component']]
]);
