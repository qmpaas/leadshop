(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-rich"],{"18b3":function(n,e,t){"use strict";t.r(e);var c=t("4dcc"),r=t("9aa4");for(var a in r)["default"].indexOf(a)<0&&function(n){t.d(e,n,(function(){return r[n]}))}(a);t("ea27");var o,u=t("5d80"),i=Object(u["a"])(r["default"],c["b"],c["c"],!1,null,"dc1363cc",null,!1,c["a"],o);e["default"]=i.exports},"4dcc":function(n,e,t){"use strict";var c;t.d(e,"b",(function(){return r})),t.d(e,"c",(function(){return a})),t.d(e,"a",(function(){return c}));var r=function(){var n=this,e=n.$createElement;n._self._c},a=[]},"9aa4":function(n,e,t){"use strict";t.r(e);var c=t("e3c9"),r=t.n(c);for(var a in c)["default"].indexOf(a)<0&&function(n){t.d(e,n,(function(){return c[n]}))}(a);e["default"]=r.a},ca88:function(n,e,t){},e3c9:function(n,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var c=function(){Promise.all([t.e("common/vendor"),t.e("components/he-html/he-html")]).then(function(){return resolve(t("7dc4"))}.bind(null,t)).catch(t.oe)},r={name:"detail-rich",props:{content:{type:[String,Array]}},components:{heRich:c}};e.default=r},ea27:function(n,e,t){"use strict";var c=t("ca88"),r=t.n(c);r.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-rich-create-component',
    {
        'pages/goods/components/detail-rich-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f0d1')['createComponent'](__webpack_require__("18b3"))
        })
    },
    [['pages/goods/components/detail-rich-create-component']]
]);
