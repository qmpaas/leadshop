(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-skeleton"],{"0e74":function(n,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"detail-skeleton"};e.default=u},6296:function(n,e,t){},aea2:function(n,e,t){"use strict";var u;t.d(e,"b",(function(){return a})),t.d(e,"c",(function(){return r})),t.d(e,"a",(function(){return u}));var a=function(){var n=this,e=n.$createElement;n._self._c},r=[]},bfeb:function(n,e,t){"use strict";t.r(e);var u=t("0e74"),a=t.n(u);for(var r in u)["default"].indexOf(r)<0&&function(n){t.d(e,n,(function(){return u[n]}))}(r);e["default"]=a.a},c5f4:function(n,e,t){"use strict";t.r(e);var u=t("aea2"),a=t("bfeb");for(var r in a)["default"].indexOf(r)<0&&function(n){t.d(e,n,(function(){return a[n]}))}(r);t("f076");var f,o=t("7702"),c=Object(o["a"])(a["default"],u["b"],u["c"],!1,null,null,null,!1,u["a"],f);e["default"]=c.exports},f076:function(n,e,t){"use strict";var u=t("6296"),a=t.n(u);a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-skeleton-create-component',
    {
        'pages/goods/components/detail-skeleton-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('255a')['createComponent'](__webpack_require__("c5f4"))
        })
    },
    [['pages/goods/components/detail-skeleton-create-component']]
]);
