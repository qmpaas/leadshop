(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-skeleton"],{b132:function(n,e,t){},b2a8:function(n,e,t){"use strict";var u;t.d(e,"b",(function(){return a})),t.d(e,"c",(function(){return f})),t.d(e,"a",(function(){return u}));var a=function(){var n=this,e=n.$createElement;n._self._c},f=[]},b8e0:function(n,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"detail-skeleton"};e.default=u},bfeb:function(n,e,t){"use strict";t.r(e);var u=t("b8e0"),a=t.n(u);for(var f in u)["default"].indexOf(f)<0&&function(n){t.d(e,n,(function(){return u[n]}))}(f);e["default"]=a.a},c5f4:function(n,e,t){"use strict";t.r(e);var u=t("b2a8"),a=t("bfeb");for(var f in a)["default"].indexOf(f)<0&&function(n){t.d(e,n,(function(){return a[n]}))}(f);t("f076");var r,c=t("f0c5"),o=Object(c["a"])(a["default"],u["b"],u["c"],!1,null,null,null,!1,u["a"],r);e["default"]=o.exports},f076:function(n,e,t){"use strict";var u=t("b132"),a=t.n(u);a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-skeleton-create-component',
    {
        'pages/goods/components/detail-skeleton-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("c5f4"))
        })
    },
    [['pages/goods/components/detail-skeleton-create-component']]
]);
