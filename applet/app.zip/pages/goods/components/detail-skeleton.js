(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-skeleton"],{"0871":function(n,e,t){},8375:function(n,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var a={name:"detail-skeleton"};e.default=a},aea2:function(n,e,t){"use strict";var a;t.d(e,"b",(function(){return u})),t.d(e,"c",(function(){return r})),t.d(e,"a",(function(){return a}));var u=function(){var n=this,e=n.$createElement;n._self._c},r=[]},bfeb:function(n,e,t){"use strict";t.r(e);var a=t("8375"),u=t.n(a);for(var r in a)["default"].indexOf(r)<0&&function(n){t.d(e,n,(function(){return a[n]}))}(r);e["default"]=u.a},c5f4:function(n,e,t){"use strict";t.r(e);var a=t("aea2"),u=t("bfeb");for(var r in u)["default"].indexOf(r)<0&&function(n){t.d(e,n,(function(){return u[n]}))}(r);t("f076");var f,o=t("98a2"),c=Object(o["a"])(u["default"],a["b"],a["c"],!1,null,null,null,!1,a["a"],f);e["default"]=c.exports},f076:function(n,e,t){"use strict";var a=t("0871"),u=t.n(a);u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-skeleton-create-component',
    {
        'pages/goods/components/detail-skeleton-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('3be4')['createComponent'](__webpack_require__("c5f4"))
        })
    },
    [['pages/goods/components/detail-skeleton-create-component']]
]);
