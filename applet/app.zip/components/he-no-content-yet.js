(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/he-no-content-yet"],{"1d5d":function(t,n,e){},2015:function(t,n,e){"use strict";var u=e("1d5d"),a=e.n(u);a.a},2837:function(t,n,e){"use strict";var u;e.d(n,"b",(function(){return a})),e.d(n,"c",(function(){return r})),e.d(n,"a",(function(){return u}));var a=function(){var t=this,n=t.$createElement;t._self._c},r=[]},"89af":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={name:"he-no-content-yet",props:{text:{type:String,default:function(){return"暂无内容"}},type:{type:String,default:""},image:{type:String,default:""}},computed:{newImage:function(){return this.image?this.image:this.ipAddress+"/goods-imgae-no.png"}}};n.default=u},aa66:function(t,n,e){"use strict";e.r(n);var u=e("2837"),a=e("e1cb");for(var r in a)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return a[t]}))}(r);e("2015");var i,o=e("98a2"),c=Object(o["a"])(a["default"],u["b"],u["c"],!1,null,"c0bef818",null,!1,u["a"],i);n["default"]=c.exports},e1cb:function(t,n,e){"use strict";e.r(n);var u=e("89af"),a=e.n(u);for(var r in u)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(r);n["default"]=a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/he-no-content-yet-create-component',
    {
        'components/he-no-content-yet-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('3be4')['createComponent'](__webpack_require__("aa66"))
        })
    },
    [['components/he-no-content-yet-create-component']]
]);
