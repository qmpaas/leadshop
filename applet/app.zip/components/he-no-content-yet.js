(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/he-no-content-yet"],{2015:function(t,e,n){"use strict";var u=n("e038"),r=n.n(u);r.a},2837:function(t,e,n){"use strict";var u;n.d(e,"b",(function(){return r})),n.d(e,"c",(function(){return a})),n.d(e,"a",(function(){return u}));var r=function(){var t=this,e=t.$createElement;t._self._c},a=[]},aa66:function(t,e,n){"use strict";n.r(e);var u=n("2837"),r=n("e1cb");for(var a in r)["default"].indexOf(a)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(a);n("2015");var i,c=n("f0c5"),o=Object(c["a"])(r["default"],u["b"],u["c"],!1,null,"c0bef818",null,!1,u["a"],i);e["default"]=o.exports},e038:function(t,e,n){},e1cb:function(t,e,n){"use strict";n.r(e);var u=n("f514"),r=n.n(u);for(var a in u)["default"].indexOf(a)<0&&function(t){n.d(e,t,(function(){return u[t]}))}(a);e["default"]=r.a},f514:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"he-no-content-yet",props:{text:{type:String,default:function(){return"暂无内容"}},type:{type:String,default:""},image:{type:String,default:""}},computed:{newImage:function(){return this.image?this.image:this.ipAddress+"/goods-imgae-no.png"}}};e.default=u}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/he-no-content-yet-create-component',
    {
        'components/he-no-content-yet-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("aa66"))
        })
    },
    [['components/he-no-content-yet-create-component']]
]);
