(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/he-no-content-yet"],{2015:function(t,e,n){"use strict";var u=n("e9b7"),r=n.n(u);r.a},2837:function(t,e,n){"use strict";var u;n.d(e,"b",(function(){return r})),n.d(e,"c",(function(){return a})),n.d(e,"a",(function(){return u}));var r=function(){var t=this,e=t.$createElement;t._self._c},a=[]},7824:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"he-no-content-yet",props:{text:{type:String,default:function(){return"暂无内容"}},type:{type:String,default:""},image:{type:String,default:""}},computed:{newImage:function(){return this.image?this.image:this.ipAddress+"/goods-imgae-no.png"}}};e.default=u},aa66:function(t,e,n){"use strict";n.r(e);var u=n("2837"),r=n("e1cb");for(var a in r)["default"].indexOf(a)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(a);n("2015");var i,o=n("522a"),c=Object(o["a"])(r["default"],u["b"],u["c"],!1,null,"c0bef818",null,!1,u["a"],i);e["default"]=c.exports},e1cb:function(t,e,n){"use strict";n.r(e);var u=n("7824"),r=n.n(u);for(var a in u)["default"].indexOf(a)<0&&function(t){n.d(e,t,(function(){return u[t]}))}(a);e["default"]=r.a},e9b7:function(t,e,n){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/he-no-content-yet-create-component',
    {
        'components/he-no-content-yet-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('35a2')['createComponent'](__webpack_require__("aa66"))
        })
    },
    [['components/he-no-content-yet-create-component']]
]);
