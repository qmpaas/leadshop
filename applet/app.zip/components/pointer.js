(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/pointer"],{"639e":function(t,e,n){"use strict";n.r(e);var r=n("d304"),a=n("85f9");for(var u in a)["default"].indexOf(u)<0&&function(t){n.d(e,t,(function(){return a[t]}))}(u);n("82a8");var o,i=n("522a"),f=Object(i["a"])(a["default"],r["b"],r["c"],!1,null,"718334fa",null,!1,r["a"],o);e["default"]=f.exports},"82a8":function(t,e,n){"use strict";var r=n("baae"),a=n.n(r);a.a},"85f9":function(t,e,n){"use strict";n.r(e);var r=n("e9b6"),a=n.n(r);for(var u in r)["default"].indexOf(u)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(u);e["default"]=a.a},baae:function(t,e,n){},d304:function(t,e,n){"use strict";var r;n.d(e,"b",(function(){return a})),n.d(e,"c",(function(){return u})),n.d(e,"a",(function(){return r}));var a=function(){var t=this,e=t.$createElement,n=(t._self._c,t.type<3?t.__map(t.number,(function(e,n){var r=t.__get_orig(e),a=t.activeColor(n);return{$orig:r,m0:a}})):null);t.$mp.data=Object.assign({},{$root:{l0:n}})},u=[]},e9b6:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={props:{current:{type:[String,Number,Boolean],default:1},number:{type:[String,Number,Boolean],default:""},margin:{type:[Number],default:8},type:{type:[String,Number,Boolean],default:1},align:{type:[String,Number,Boolean],default:"left"},color:{type:[String,Number,Boolean],default:"#f44"}},methods:{activeColor:function(t){return this.current==t?this.color:"rgba(0,0,0,.3)"}}};e.default=r}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/pointer-create-component',
    {
        'components/pointer-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('35a2')['createComponent'](__webpack_require__("639e"))
        })
    },
    [['components/pointer-create-component']]
]);
