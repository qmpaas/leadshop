(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/pointer"],{"635f":function(e,t,n){},"639e":function(e,t,n){"use strict";n.r(t);var r=n("edfe"),u=n("85f9");for(var o in u)["default"].indexOf(o)<0&&function(e){n.d(t,e,(function(){return u[e]}))}(o);n("77b7");var a,f=n("522a"),i=Object(f["a"])(u["default"],r["b"],r["c"],!1,null,"6f1dbd6d",null,!1,r["a"],a);t["default"]=i.exports},"77b7":function(e,t,n){"use strict";var r=n("635f"),u=n.n(r);u.a},"85f9":function(e,t,n){"use strict";n.r(t);var r=n("e9b6"),u=n.n(r);for(var o in r)["default"].indexOf(o)<0&&function(e){n.d(t,e,(function(){return r[e]}))}(o);t["default"]=u.a},e9b6:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r={props:{current:{type:[String,Number,Boolean],default:1},number:{type:[String,Number,Boolean],default:""},margin:{type:[Number],default:8},type:{type:[String,Number,Boolean],default:1},align:{type:[String,Number,Boolean],default:"left"},color:{type:[String,Number,Boolean],default:"#f44"}},methods:{activeColor:function(e){return this.current==e?this.color:"rgba(0,0,0,.3)"}}};t.default=r},edfe:function(e,t,n){"use strict";var r;n.d(t,"b",(function(){return u})),n.d(t,"c",(function(){return o})),n.d(t,"a",(function(){return r}));var u=function(){var e=this,t=e.$createElement,n=(e._self._c,e.type<3?e.__map(e.number,(function(t,n){var r=e.__get_orig(t),u=e.activeColor(n);return{$orig:r,m0:u}})):null);e.$mp.data=Object.assign({},{$root:{l0:n}})},o=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/pointer-create-component',
    {
        'components/pointer-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('35a2')['createComponent'](__webpack_require__("639e"))
        })
    },
    [['components/pointer-create-component']]
]);
