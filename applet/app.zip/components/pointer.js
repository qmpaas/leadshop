(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/pointer"],{"1d00":function(t,e,n){},"639e":function(t,e,n){"use strict";n.r(e);var r=n("d304"),u=n("85f9");for(var a in u)["default"].indexOf(a)<0&&function(t){n.d(e,t,(function(){return u[t]}))}(a);n("82a8");var o,i=n("8add"),f=Object(i["a"])(u["default"],r["b"],r["c"],!1,null,"718334fa",null,!1,r["a"],o);e["default"]=f.exports},"82a8":function(t,e,n){"use strict";var r=n("1d00"),u=n.n(r);u.a},"85f9":function(t,e,n){"use strict";n.r(e);var r=n("a5b1"),u=n.n(r);for(var a in r)["default"].indexOf(a)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(a);e["default"]=u.a},a5b1:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={props:{current:{type:[String,Number,Boolean],default:1},number:{type:[String,Number,Boolean],default:""},margin:{type:[Number],default:8},type:{type:[String,Number,Boolean],default:1},align:{type:[String,Number,Boolean],default:"left"},color:{type:[String,Number,Boolean],default:"#f44"}},methods:{activeColor:function(t){return this.current==t?this.color:"rgba(0,0,0,.3)"}}};e.default=r},d304:function(t,e,n){"use strict";var r;n.d(e,"b",(function(){return u})),n.d(e,"c",(function(){return a})),n.d(e,"a",(function(){return r}));var u=function(){var t=this,e=t.$createElement,n=(t._self._c,t.type<3?t.__map(t.number,(function(e,n){var r=t.__get_orig(e),u=t.activeColor(n);return{$orig:r,m0:u}})):null);t.$mp.data=Object.assign({},{$root:{l0:n}})},a=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/pointer-create-component',
    {
        'components/pointer-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('a9ee')['createComponent'](__webpack_require__("639e"))
        })
    },
    [['components/pointer-create-component']]
]);
