(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["promoter/pages/components/video"],{"2cf3":function(t,e,n){"use strict";n.r(e);var i=n("402e"),u=n.n(i);for(var r in i)["default"].indexOf(r)<0&&function(t){n.d(e,t,(function(){return i[t]}))}(r);e["default"]=u.a},"402e":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var i={name:"video",props:{src:{type:String,required:!0},poster:{type:String},value:{type:[Number,null]},index:{type:Number}},data:function(){return{isPlay:!1}},methods:{playVideo:function(){this.isPlay?this.$emit("input",null):this.$emit("input",this.index)}},watch:{value:{handler:function(t){t!==this.index?this.isPlay=!1:this.isPlay=!0},immediate:!0,deep:!0}},mounted:function(){}};e.default=i},4376:function(t,e,n){"use strict";n.r(e);var i=n("de04"),u=n("2cf3");for(var r in u)["default"].indexOf(r)<0&&function(t){n.d(e,t,(function(){return u[t]}))}(r);n("62e4");var a,o=n("8add"),c=Object(o["a"])(u["default"],i["b"],i["c"],!1,null,"3698f38d",null,!1,i["a"],a);e["default"]=c.exports},"62a9":function(t,e,n){},"62e4":function(t,e,n){"use strict";var i=n("62a9"),u=n.n(i);u.a},de04:function(t,e,n){"use strict";var i;n.d(e,"b",(function(){return u})),n.d(e,"c",(function(){return r})),n.d(e,"a",(function(){return i}));var u=function(){var t=this,e=t.$createElement;t._self._c},r=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'promoter/pages/components/video-create-component',
    {
        'promoter/pages/components/video-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('a9ee')['createComponent'](__webpack_require__("4376"))
        })
    },
    [['promoter/pages/components/video-create-component']]
]);
