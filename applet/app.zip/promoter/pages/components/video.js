(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["promoter/pages/components/video"],{2451:function(t,n,e){"use strict";var i;e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return a})),e.d(n,"a",(function(){return i}));var u=function(){var t=this,n=t.$createElement;t._self._c},a=[]},"2cf3":function(t,n,e){"use strict";e.r(n);var i=e("c873"),u=e.n(i);for(var a in i)["default"].indexOf(a)<0&&function(t){e.d(n,t,(function(){return i[t]}))}(a);n["default"]=u.a},"308a":function(t,n,e){},4376:function(t,n,e){"use strict";e.r(n);var i=e("2451"),u=e("2cf3");for(var a in u)["default"].indexOf(a)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(a);e("c3a5");var r,c=e("f0c5"),o=Object(c["a"])(u["default"],i["b"],i["c"],!1,null,"08a0c1e6",null,!1,i["a"],r);n["default"]=o.exports},c3a5:function(t,n,e){"use strict";var i=e("308a"),u=e.n(i);u.a},c873:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var i={name:"video",props:{src:{type:String,required:!0},poster:{type:String},value:{type:[Number,null]},index:{type:Number}},data:function(){return{isPlay:!1}},methods:{playVideo:function(){this.isPlay?this.$emit("input",null):this.$emit("input",this.index)}},watch:{value:{handler:function(t){t!==this.index?this.isPlay=!1:this.isPlay=!0},immediate:!0,deep:!0}},mounted:function(){}};n.default=i}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'promoter/pages/components/video-create-component',
    {
        'promoter/pages/components/video-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("4376"))
        })
    },
    [['promoter/pages/components/video-create-component']]
]);
