(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["promoter/pages/components/video"],{"0fa9":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var i={name:"video",props:{src:{type:String,required:!0},poster:{type:String},value:{type:[Number,null]},index:{type:Number}},data:function(){return{isPlay:!1}},methods:{playVideo:function(){this.isPlay?this.$emit("input",null):this.$emit("input",this.index)}},watch:{value:{handler:function(t){t!==this.index?this.isPlay=!1:this.isPlay=!0},immediate:!0,deep:!0}},mounted:function(){}};n.default=i},"2cf3":function(t,n,e){"use strict";e.r(n);var i=e("0fa9"),u=e.n(i);for(var r in i)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return i[t]}))}(r);n["default"]=u.a},4376:function(t,n,e){"use strict";e.r(n);var i=e("f55f"),u=e("2cf3");for(var r in u)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(r);e("c291");var a,c=e("5d80"),f=Object(c["a"])(u["default"],i["b"],i["c"],!1,null,"90ca73da",null,!1,i["a"],a);n["default"]=f.exports},c291:function(t,n,e){"use strict";var i=e("d2bb"),u=e.n(i);u.a},d2bb:function(t,n,e){},f55f:function(t,n,e){"use strict";var i;e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return r})),e.d(n,"a",(function(){return i}));var u=function(){var t=this,n=t.$createElement;t._self._c},r=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'promoter/pages/components/video-create-component',
    {
        'promoter/pages/components/video-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f0d1')['createComponent'](__webpack_require__("4376"))
        })
    },
    [['promoter/pages/components/video-create-component']]
]);
