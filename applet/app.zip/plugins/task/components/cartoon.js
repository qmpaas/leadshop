(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/task/components/cartoon"],{"4cc8":function(t,n,e){},7100:function(t,n,e){"use strict";e.r(n);var u=e("fc59"),c=e.n(u);for(var o in u)["default"].indexOf(o)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(o);n["default"]=c.a},9112:function(t,n,e){"use strict";e.r(n);var u=e("e858"),c=e("7100");for(var o in c)["default"].indexOf(o)<0&&function(t){e.d(n,t,(function(){return c[t]}))}(o);e("bf04");var a,i=e("522a"),r=Object(i["a"])(c["default"],u["b"],u["c"],!1,null,"2c4f554f",null,!1,u["a"],a);n["default"]=r.exports},bf04:function(t,n,e){"use strict";var u=e("4cc8"),c=e.n(u);c.a},e858:function(t,n,e){"use strict";var u;e.d(n,"b",(function(){return c})),e.d(n,"c",(function(){return o})),e.d(n,"a",(function(){return u}));var c=function(){var t=this,n=t.$createElement,u=(t._self._c,t.display?e("e547"):null),c=t.display?e("8b30"):null;t.$mp.data=Object.assign({},{$root:{m0:u,m1:c}})},o=[]},fc59:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={props:{value:{type:[Number,Boolean],default:0},score:{type:[String,Number],default:"10"},title:{type:[String,Number],default:"领取成功"}},watch:{},computed:{display:{get:function(){return this.value},set:function(){this.$emit("input",0)}}},mounted:function(){},methods:{toclose:function(){console.log("功能执行",this),this.display=!1}}};n.default=u}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/task/components/cartoon-create-component',
    {
        'plugins/task/components/cartoon-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('35a2')['createComponent'](__webpack_require__("9112"))
        })
    },
    [['plugins/task/components/cartoon-create-component']]
]);
