(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/task/components/cartoon"],{"04fb":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={props:{value:{type:[Number,Boolean],default:0},score:{type:[String,Number],default:"10"},title:{type:[String,Number],default:"领取成功"}},watch:{},computed:{display:{get:function(){return this.value},set:function(){this.$emit("input",0)}}},mounted:function(){},methods:{toclose:function(){console.log("功能执行",this),this.display=!1}}};e.default=u},"2afb":function(t,e,n){},7100:function(t,e,n){"use strict";n.r(e);var u=n("04fb"),a=n.n(u);for(var o in u)["default"].indexOf(o)<0&&function(t){n.d(e,t,(function(){return u[t]}))}(o);e["default"]=a.a},9112:function(t,e,n){"use strict";n.r(e);var u=n("b142"),a=n("7100");for(var o in a)["default"].indexOf(o)<0&&function(t){n.d(e,t,(function(){return a[t]}))}(o);n("e983e");var i,r=n("f0c5"),c=Object(r["a"])(a["default"],u["b"],u["c"],!1,null,"5696eed9",null,!1,u["a"],i);e["default"]=c.exports},b142:function(t,e,n){"use strict";var u;n.d(e,"b",(function(){return a})),n.d(e,"c",(function(){return o})),n.d(e,"a",(function(){return u}));var a=function(){var t=this,e=t.$createElement,u=(t._self._c,t.display?n("e547"):null),a=t.display?n("8b30"):null;t.$mp.data=Object.assign({},{$root:{m0:u,m1:a}})},o=[]},e983e:function(t,e,n){"use strict";var u=n("2afb"),a=n.n(u);a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/task/components/cartoon-create-component',
    {
        'plugins/task/components/cartoon-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("9112"))
        })
    },
    [['plugins/task/components/cartoon-create-component']]
]);
