(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/task/sort"],{"36a6":function(t,n,e){},"74ec":function(t,n,e){"use strict";e.r(n);var r=e("a0a3"),u=e("b88c");for(var s in u)["default"].indexOf(s)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(s);e("cf9c");var a,i=e("7702"),c=Object(i["a"])(u["default"],r["b"],r["c"],!1,null,"2bef0871",null,!1,r["a"],a);n["default"]=c.exports},"997b3":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"list-sort",data:function(){return{key:"sort",sort:"DESC"}},methods:{setActive:function(t){this.key=t,"t.task_number"===t?"ASC"===this.sort?this.sort="DESC":this.sort="ASC":this.sort="DESC",this.$emit("sort",{key:this.key,value:this.sort})}}};n.default=r},a0a3:function(t,n,e){"use strict";var r;e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return s})),e.d(n,"a",(function(){return r}));var u=function(){var t=this,n=t.$createElement;t._self._c},s=[]},b88c:function(t,n,e){"use strict";e.r(n);var r=e("997b3"),u=e.n(r);for(var s in r)["default"].indexOf(s)<0&&function(t){e.d(n,t,(function(){return r[t]}))}(s);n["default"]=u.a},cf9c:function(t,n,e){"use strict";var r=e("36a6"),u=e.n(r);u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/task/sort-create-component',
    {
        'plugins/task/sort-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('255a')['createComponent'](__webpack_require__("74ec"))
        })
    },
    [['plugins/task/sort-create-component']]
]);
