(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/task/sort"],{1084:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"list-sort",data:function(){return{key:"sort",sort:"DESC"}},methods:{setActive:function(t){this.key=t,"t.task_number"===t?"ASC"===this.sort?this.sort="DESC":this.sort="ASC":this.sort="DESC",this.$emit("sort",{key:this.key,value:this.sort})}}};n.default=r},"1dfa":function(t,n,e){},"74ec":function(t,n,e){"use strict";e.r(n);var r=e("a0a3"),u=e("b88c");for(var a in u)["default"].indexOf(a)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(a);e("cf9c");var s,i=e("522a"),c=Object(i["a"])(u["default"],r["b"],r["c"],!1,null,"2bef0871",null,!1,r["a"],s);n["default"]=c.exports},a0a3:function(t,n,e){"use strict";var r;e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return a})),e.d(n,"a",(function(){return r}));var u=function(){var t=this,n=t.$createElement;t._self._c},a=[]},b88c:function(t,n,e){"use strict";e.r(n);var r=e("1084"),u=e.n(r);for(var a in r)["default"].indexOf(a)<0&&function(t){e.d(n,t,(function(){return r[t]}))}(a);n["default"]=u.a},cf9c:function(t,n,e){"use strict";var r=e("1dfa"),u=e.n(r);u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/task/sort-create-component',
    {
        'plugins/task/sort-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('35a2')['createComponent'](__webpack_require__("74ec"))
        })
    },
    [['plugins/task/sort-create-component']]
]);
