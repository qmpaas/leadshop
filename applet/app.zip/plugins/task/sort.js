(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/task/sort"],{1084:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"list-sort",data:function(){return{key:"sort",sort:"DESC"}},methods:{setActive:function(t){this.key=t,"t.task_number"===t?"ASC"===this.sort?this.sort="DESC":this.sort="ASC":this.sort="DESC",this.$emit("sort",{key:this.key,value:this.sort})}}};n.default=r},"2c99":function(t,n,e){},"46d2":function(t,n,e){"use strict";var r=e("2c99"),u=e.n(r);u.a},"74ec":function(t,n,e){"use strict";e.r(n);var r=e("ac3f"),u=e("b88c");for(var s in u)["default"].indexOf(s)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(s);e("46d2");var i,c=e("522a"),a=Object(c["a"])(u["default"],r["b"],r["c"],!1,null,"bcfa00fc",null,!1,r["a"],i);n["default"]=a.exports},ac3f:function(t,n,e){"use strict";var r;e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return s})),e.d(n,"a",(function(){return r}));var u=function(){var t=this,n=t.$createElement;t._self._c},s=[]},b88c:function(t,n,e){"use strict";e.r(n);var r=e("1084"),u=e.n(r);for(var s in r)["default"].indexOf(s)<0&&function(t){e.d(n,t,(function(){return r[t]}))}(s);n["default"]=u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/task/sort-create-component',
    {
        'plugins/task/sort-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('35a2')['createComponent'](__webpack_require__("74ec"))
        })
    },
    [['plugins/task/sort-create-component']]
]);
