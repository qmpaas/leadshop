worker.onMessage(function (res) {
})
